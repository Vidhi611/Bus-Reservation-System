
package busreservation;

import java.util.Scanner;


public class Destination {
    
     public void showDestinationScreen()
    {
         System.out.print("\n[1] Bangalore \n[2] Mangalore \n[3] Hyderabad \n[4] Pune \n[5] Goa \n\nChoose destination: ");
           
    }
     
    public String getDestination()
    {
        String destination;
        
         Scanner booking = new Scanner(System.in);
         int location = Integer.parseInt(booking.nextLine());

                switch (location)
                {
                    case 1: destination = "Bangalore";
                           // price = 8.0;
                            break;
                    
                    case 2: destination = "Mangalore";
                           // price = 13.0;
                            break;
                
                    case 3: destination = "Hyderabad";
                           // price = 12.0;
                            break;
                    
                    case 4: destination = "Pune";
                           // price = 15.0;
                            break;
                    
                    case 5: destination = "Goa";
                           // price = 17.0;
                            break;
                    
                    default: destination = "Invalid input!";
                            break;
                }
        
        return destination;
    }
    
}